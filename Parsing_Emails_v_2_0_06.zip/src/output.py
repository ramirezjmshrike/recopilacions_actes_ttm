'''
Aquest fitxer de moment no conté cap subfunció,
tot i que sí es preveu que en el futur sí
s'elaborin subfuncions per aquest.
'''

